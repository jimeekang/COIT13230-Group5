const express = require("express");
const app = express();
const MongoClient = require("mongodb").MongoClient;
let db;

const date = new Date();
const formattedDate = date.toLocaleDateString("en-GB", {
  year: "numeric",
  month: "2-digit",
  day: "2-digit",
});
require("dotenv").config();

app.use(express.static("Front"));
app.use(express.urlencoded({ extended: true }));

// Mongo DB Connect
MongoClient.connect(
  process.env.DB_URL,
  { useUnifiedTopology: true },
  (err, client) => {
    if (err) return console.log(err);

    db = client.db("elecspectra");

    app.listen(process.env.PORT, () => {
      console.log("listening on 3000");
    });
  }
);

app.get("/", (req, res) => {
  res.render("/index.html");
});

/******    SiGN UP     **** */
app.get("/signup", (req, res) => {
  res.render("/signup.html");
});

// get the data from sign-up page
app.post("/createid", (req, res) => {
  //console.log(req.body);

  // save db
  const { fullName, email, gender, password, address, phoneNumber } = req.body;
  db.collection("user").insertOne(
    {
      _id: Math.random(),
      fullName,
      email,
      gender,
      password,
      address,
      phoneNumber,
      date: formattedDate,
      role: "user",
    },
    (error, result) => {
      if (error) {
        console.error("Error inserting document:", error);
      } else {
        console.log("Document inserted successfully:"); // Access the generated ID
      }
    }
  );
  res.redirect("/login.html");
});

/******   Login Session Authentication     *****/
const passport = require("passport");
const LocalStrategy = require("passport-local").Strategy;
const session = require("express-session");

/******    Middle Ware Setting      **** */
app.use(
  session({ secret: "secretcode", resave: true, saveUninitialized: false })
);
app.use(passport.initialize());
app.use(passport.session());

/******   LOGIN     **** */
app.get("/login", (req, rep) => {
  rep.render("/login.html");
});

app.post(
  "/login",
  passport.authenticate("local", {
    failureRedirect: "/fail",
  }),
  (req, rep) => {
    rep.redirect("/index.html");
  }
);

passport.use(
  new LocalStrategy(
    {
      usernameField: "email",
      passwordField: "password",
      session: true,
      passReqToCallback: false,
    },
    // check user email and password
    (email, password, done) => {
      //console.log(email, password);

      db.collection("user").findOne({ email }, (err, result) => {
        if (err) return done(err);

        if (!result)
          return done(null, false, { message: "Your Email is not exist!" });

        // Find Password
        if (password == result.password) {
          return done(null, result);
        } else {
          return done(null, false, { message: "Check your Password again!" });
        }
      });
    }
  )
);

//  show only one login that only those with a session can enter
app.get("/home", loginCheck, (req, rep) => {
  rep.render("/index.html");
});

app.get("/api/user", loginCheck, (req, res) => {
  if (req.user) {
    res.json({ user: req.user }); // Send user object in JSON format
  } else {
    res.sendStatus(401); // Unauthorized if not logged in
  }
});

// Middle Ware (login checking)
function loginCheck(req, rep, next) {
  if (req.user) {
    next();
  } else {
    rep.send("Pleas login for your ID");
  }
}

/*Code to save the session (activated upon successful login), 
  when you want to keep the session */
passport.serializeUser((user, done) => {
  done(null, user.email);
});

/* Launch when accessing my page 
  => role to find the personal information of the logged-in user in the DB */
passport.deserializeUser((email, done) => {
  db.collection("user").findOne({ email }, (err, result) => {
    done(null, { result });
  });
});

/******   LOGOUT     **** */
app.get("/logout", (req, res) => {
  req.logout((err, result) => {
    console.log(" Logout Successfully");
    res.redirect("/");
  });
});
