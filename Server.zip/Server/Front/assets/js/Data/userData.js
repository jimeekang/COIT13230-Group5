const users = [
  {
    email: "kjm12081@gmail.com",
    password: 123456,
    confirmPassword: 123456,
    firstName: "Jimee",
    lastName: "Kang",
    address: "Lidcombe Sydney 2141",
    phoneNumber: 1487989571,
    registrationDate: new Date(),
    role: "customer",
  },
  {
    email: "k_k1208@naver.com",
    password: 123456,
    confirmPassword: 123456,
    firstName: "Ingko",
    lastName: "Sim",
    address: "Lidcombe Sydney 2141",
    phoneNumber: 1234567890,
    registrationDate: new Date(),
    role: "admin",
  },
];

export default users;
