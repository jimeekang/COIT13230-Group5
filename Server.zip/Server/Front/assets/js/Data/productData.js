const products = [
  {
    productId: 1,
    name: "camera",
    description: "pink camera",
    price: 100,
    brand: "Insdax",
    quantity: 2,
  },
  {
    productId: 2,
    name: "Iphone 15",
    description: "256GB",
    price: 2000,
    brand: "Apple",
    quantity: 3,
  },
];

export default products;
